#ifndef __LCS_H__
#define __LCS_H__

#ifdef __cplusplus
extern "C" {
#endif
	int get_lcs(int len, int A[]);
	void find_permutation(int n, int res[]);
#ifdef __cplusplus
}
#endif

#endif
